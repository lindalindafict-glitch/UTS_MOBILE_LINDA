
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  ScrollView,
  Alert,
} from 'react-native';

const C = {
  bg: '#FFF7FA',
  white: '#FFFFFF',
  pink: '#D95F87',
  dark: '#35232D',
  muted: '#927D87',
  lightPink: '#FCE7EF',
  border: '#F1DCE5',
};

export default function App() {
  const [page, setPage] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [user, setUser] = useState('');
  const [selectedMenu, setSelectedMenu] = useState('');

  const menus = [
    {
      title: 'Profil',
      icon: '◉',
      desc: 'Informasi akun dan identitas pengguna.',
    },
    {
      title: 'Aktivitas',
      icon: '▤',
      desc: 'Lihat aktivitas dan kegiatan kamu.',
    },
    {
      title: 'Notifikasi',
      icon: '♧',
      desc: 'Pusat pemberitahuan aplikasi.',
    },
    {
      title: 'Pengaturan',
      icon: '⚙',
      desc: 'Atur preferensi aplikasi kamu.',
    },
  ];

  function handleLogin() {
    const cleanEmail = email.trim();

    if (!cleanEmail || !password.trim()) {
      Alert.alert(
        'Belum lengkap',
        'Masukkan email dan password terlebih dahulu.'
      );
      return;
    }

    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      Alert.alert('Email tidak valid', 'Masukkan alamat email yang benar.');
      return;
    }

    const name = cleanEmail
      .split('@')[0]
      .replace(/[._-]/g, ' ')
      .replace(/\b\w/g, letter => letter.toUpperCase());

    setUser(name);
    setPage('home');
  }

  function handleLogout() {
    Alert.alert('Keluar dari akun?', 'Kamu akan kembali ke halaman login.', [
      { text: 'Batal', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: () => {
          setPage('login');
          setEmail('');
          setPassword('');
          setSelectedMenu('');
          setShowPassword(false);
        },
      },
    ]);
  }

  function openMenu(title) {
    setSelectedMenu(title);
    setPage('menu');
  }

  function renderLogin() {
    return (
      <ScrollView
        contentContainerStyle={styles.loginScroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.loginTop}>
          <View style={styles.brandIcon}>
            <Text style={styles.brandIconText}>L.</Text>
          </View>

          <Text style={styles.eyebrow}>WELCOME TO</Text>
          <Text style={styles.appTitle}>My Personal App</Text>
          <Text style={styles.subtitle}>
            Satu tempat untuk mengelola aktivitasmu.
          </Text>
        </View>

        <View style={styles.loginCard}>
          <Text style={styles.cardTitle}>Login</Text>
          <Text style={styles.cardSubtitle}>
            Masuk untuk melanjutkan ke akunmu.
          </Text>

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="nama@email.com"
            placeholderTextColor="#B5A2AB"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.label}>Password</Text>
          <View style={styles.passwordBox}>
            <TextInput
              style={styles.passwordInput}
              placeholder="Masukkan password"
              placeholderTextColor="#B5A2AB"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              autoCapitalize="none"
            />
            <TouchableOpacity
              style={styles.showButton}
              onPress={() => setShowPassword(!showPassword)}
            >
              <Text style={styles.showText}>
                {showPassword ? 'Sembunyikan' : 'Lihat'}
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.primaryButton}
            onPress={handleLogin}
            activeOpacity={0.8}
          >
            <Text style={styles.primaryButtonText}>Masuk ke Akun  →</Text>
          </TouchableOpacity>

          <Text style={styles.loginNote}>
            Demo aplikasi · Gunakan email dan password apa saja
          </Text>
        </View>

        <Text style={styles.footer}>MADE WITH CARE · MY APP</Text>
      </ScrollView>
    );
  }

  function renderHome() {
    return (
      <ScrollView
        contentContainerStyle={styles.pageContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <View>
            <Text style={styles.eyebrow}>MY PERSONAL APP</Text>
            <Text style={styles.appTitleSmall}>Beranda</Text>
          </View>

          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user.charAt(0).toUpperCase()}
            </Text>
          </View>
        </View>

        <View style={styles.welcomeCard}>
          <View style={styles.welcomeLabel}>
            <Text style={styles.welcomeSmall}>YOUR PERSONAL SPACE</Text>
          </View>

          <Text style={styles.welcomeTitle}>Halo, {user}!</Text>

          <Text style={styles.welcomeDesc}>
            Selamat datang kembali. Siap menjalani aktivitas hari ini?
          </Text>

          <View style={styles.welcomeBottom}>
            <Text style={styles.welcomeTagText}>MAKE TODAY COUNT</Text>
            <Text style={styles.welcomeArrow}>↗</Text>
          </View>
        </View>

        <View style={styles.sectionHeading}>
          <Text style={styles.sectionTitle}>Menu Utama</Text>
          <Text style={styles.sectionSubtitle}>
            Pilih menu untuk melanjutkan
          </Text>
        </View>

        <View style={styles.menuGrid}>
          {menus.map((menu, index) => (
            <TouchableOpacity
              key={menu.title}
              style={styles.menuCard}
              onPress={() => openMenu(menu.title)}
              activeOpacity={0.75}
            >
              <View
                style={[
                  styles.menuIcon,
                  index % 2 === 0 ? styles.iconPink : styles.iconCream,
                ]}
              >
                <Text style={styles.menuIconText}>{menu.icon}</Text>
              </View>

              <Text style={styles.menuTitle}>{menu.title}</Text>
              <Text style={styles.menuDesc}>{menu.desc}</Text>

              <View style={styles.menuFooter}>
                <Text style={styles.menuArrow}>Lihat detail</Text>
                <Text style={styles.smallArrow}>→</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.bottomCard}>
          <View style={styles.bottomCardText}>
            <Text style={styles.bottomTitle}>Butuh istirahat?</Text>
            <Text style={styles.bottomDesc}>
              Atur aktivitasmu dengan nyaman.
            </Text>
          </View>
          <Text style={styles.bottomSymbol}>✦</Text>
        </View>

        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
          activeOpacity={0.8}
        >
          <Text style={styles.logoutText}>Keluar dari akun</Text>
        </TouchableOpacity>

        <Text style={styles.homeFooter}>MY PERSONAL APP · 2026</Text>
      </ScrollView>
    );
  }

  function renderMenu() {
    const item = menus.find(menu => menu.title === selectedMenu);

    return (
      <ScrollView
        contentContainerStyle={styles.pageContent}
        showsVerticalScrollIndicator={false}
      >
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setPage('home')}
          activeOpacity={0.7}
        >
          <Text style={styles.backText}>←  Kembali ke Home</Text>
        </TouchableOpacity>

        <View style={styles.detailCard}>
          <View style={styles.detailIcon}>
            <Text style={styles.detailIconText}>
              {item ? item.icon : '◉'}
            </Text>
          </View>
          <Text style={styles.eyebrow}>MY PERSONAL SPACE</Text>
          <Text style={styles.detailTitle}>{selectedMenu}</Text>
          <Text style={styles.detailDesc}>{item ? item.desc : ''}</Text>
        </View>

        {selectedMenu === 'Profil' && (
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Informasi Akun</Text>
            <Text style={styles.infoLabel}>Nama pengguna</Text>
            <Text style={styles.infoValue}>{user}</Text>
            <Text style={styles.infoLabel}>Email</Text>
            <Text style={styles.infoValue}>{email}</Text>
          </View>
        )}

        {selectedMenu === 'Aktivitas' && (
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Aktivitas Kamu</Text>
            <Text style={styles.infoValue}>
              Kamu berhasil masuk ke aplikasi.
            </Text>
            <Text style={styles.infoLabel}>Status akun</Text>
            <Text style={styles.statusText}>●  Aktif</Text>
          </View>
        )}

        {selectedMenu === 'Notifikasi' && (
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Pemberitahuan</Text>
            <Text style={styles.infoValue}>
              Semua sudah siap! Selamat menggunakan aplikasi.
            </Text>
          </View>
        )}

        {selectedMenu === 'Pengaturan' && (
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Preferensi Aplikasi</Text>
            <Text style={styles.infoLabel}>Tema aplikasi</Text>
            <Text style={styles.statusText}>●  Elegant Pink</Text>
            <Text style={styles.infoLabel}>Pengguna</Text>
            <Text style={styles.infoValue}>{user}</Text>
            <TouchableOpacity
              style={styles.settingButton}
              onPress={() =>
                Alert.alert(
                  'Informasi aplikasi',
                  'My Personal App adalah aplikasi praktikum mobile.'
                )
              }
            >
              <Text style={styles.settingButtonText}>Tentang Aplikasi</Text>
            </TouchableOpacity>
          </View>
        )}

        <TouchableOpacity
          style={styles.primaryButton}
          onPress={() => setPage('home')}
          activeOpacity={0.8}
        >
          <Text style={styles.primaryButtonText}>Kembali ke Home  →</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor={C.bg} />
      {page === 'login'
        ? renderLogin()
        : page === 'home'
        ? renderHome()
        : renderMenu()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },

  loginScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 30,
  },
  loginTop: {
    alignItems: 'center',
    marginBottom: 28,
  },
  brandIcon: {
    width: 64,
    height: 64,
    borderRadius: 21,
    backgroundColor: C.pink,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    elevation: 5,
    shadowColor: C.pink,
    shadowOpacity: 0.2,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
  },
  brandIconText: {
    fontSize: 30,
    fontWeight: '800',
    color: C.white,
  },
  eyebrow: {
    fontSize: 10,
    letterSpacing: 2.2,
    fontWeight: '800',
    color: C.pink,
    marginBottom: 8,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: C.dark,
    letterSpacing: -0.7,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    color: C.muted,
    marginTop: 9,
    textAlign: 'center',
    lineHeight: 20,
  },
  loginCard: {
    backgroundColor: C.white,
    borderRadius: 25,
    padding: 23,
    borderWidth: 1,
    borderColor: '#F8EAF0',
    elevation: 4,
    shadowColor: '#B76D89',
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 6 },
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: C.dark,
  },
  cardSubtitle: {
    fontSize: 12,
    color: C.muted,
    marginTop: 7,
    marginBottom: 25,
  },
  label: {
    fontSize: 12,
    fontWeight: '700',
    color: C.dark,
    marginBottom: 9,
  },
  input: {
    height: 51,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: '#FFFBFD',
    borderRadius: 13,
    paddingHorizontal: 14,
    color: C.dark,
    fontSize: 13,
    marginBottom: 20,
  },
  passwordBox: {
    minHeight: 51,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: '#FFFBFD',
    borderRadius: 13,
    paddingLeft: 14,
    marginBottom: 23,
  },
  passwordInput: {
    flex: 1,
    minHeight: 49,
    color: C.dark,
    fontSize: 13,
  },
  showButton: {
    paddingHorizontal: 12,
    paddingVertical: 14,
  },
  showText: {
    color: C.pink,
    fontSize: 11,
    fontWeight: '700',
  },
  primaryButton: {
    minHeight: 51,
    backgroundColor: C.pink,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 4,
    elevation: 3,
    shadowColor: C.pink,
    shadowOpacity: 0.18,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 4 },
  },
  primaryButtonText: {
    color: C.white,
    fontSize: 14,
    fontWeight: '800',
  },
  loginNote: {
    color: C.muted,
    fontSize: 10,
    textAlign: 'center',
    marginTop: 18,
    lineHeight: 16,
  },
  footer: {
    textAlign: 'center',
    color: '#B49AA5',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 2,
    marginTop: 25,
  },

  pageContent: {
    paddingHorizontal: 22,
    paddingTop: 25,
    paddingBottom: 30,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  appTitleSmall: {
    fontSize: 30,
    color: C.dark,
    fontWeight: '800',
    letterSpacing: -0.8,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 17,
    backgroundColor: C.lightPink,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: C.border,
  },
  avatarText: {
    color: C.pink,
    fontWeight: '800',
    fontSize: 20,
  },
  welcomeCard: {
    backgroundColor: C.pink,
    borderRadius: 23,
    padding: 22,
    marginBottom: 28,
  },
  welcomeLabel: {
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF30',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 7,
    marginBottom: 18,
  },
  welcomeSmall: {
    color: C.white,
    fontSize: 10,
    letterSpacing: 1.5,
    fontWeight: '800',
  },
  welcomeTitle: {
    color: C.white,
    fontSize: 27,
    fontWeight: '800',
    marginTop: 2,
  },
  welcomeDesc: {
    color: '#FFF4F7',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 9,
  },
  welcomeBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 23,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: '#FFFFFF50',
  },
  welcomeTagText: {
    color: C.white,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.3,
  },
  welcomeArrow: {
    color: C.white,
    fontSize: 23,
    fontWeight: '700',
  },
  sectionHeading: {
    marginBottom: 17,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: C.dark,
  },
  sectionSubtitle: {
    color: C.muted,
    fontSize: 12,
    marginTop: 5,
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  menuCard: {
    width: '48%',
    minHeight: 172,
    backgroundColor: C.white,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#F3E3EA',
    padding: 15,
    marginBottom: 13,
    elevation: 2,
    shadowColor: '#9D617A',
    shadowOpacity: 0.06,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 3 },
  },
  menuIcon: {
    width: 42,
    height: 42,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 13,
  },
  iconPink: {
    backgroundColor: '#FCE7EF',
  },
  iconCream: {
    backgroundColor: '#FFF0E5',
  },
  menuIconText: {
    color: C.pink,
    fontSize: 21,
    fontWeight: '700',
  },
  menuTitle: {
    fontSize: 15,
    color: C.dark,
    fontWeight: '800',
    marginBottom: 6,
  },
  menuDesc: {
    color: C.muted,
    fontSize: 11,
    lineHeight: 16,
  },
  menuFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  menuArrow: {
    color: C.pink,
    fontSize: 11,
    fontWeight: '800',
  },
  smallArrow: {
    color: C.pink,
    fontSize: 14,
    fontWeight: '800',
    marginLeft: 6,
  },
  bottomCard: {
    backgroundColor: C.white,
    borderWidth: 1,
    borderColor: '#F3E3EA',
    borderRadius: 17,
    padding: 17,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 5,
    marginBottom: 14,
  },
  bottomCardText: {
    flex: 1,
  },
  bottomTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: C.dark,
  },
  bottomDesc: {
    fontSize: 11,
    color: C.muted,
    marginTop: 5,
  },
  bottomSymbol: {
    fontSize: 25,
    color: C.pink,
    marginLeft: 12,
  },
  logoutButton: {
    borderWidth: 1,
    borderColor: '#EACAD7',
    borderRadius: 13,
    minHeight: 46,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: C.white,
  },
  logoutText: {
    color: C.pink,
    fontSize: 13,
    fontWeight: '700',
  },
  homeFooter: {
    textAlign: 'center',
    color: '#B49AA5',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.8,
    marginTop: 19,
  },

  backButton: {
    alignSelf: 'flex-start',
    paddingVertical: 10,
    marginBottom: 23,
  },
  backText: {
    color: C.pink,
    fontWeight: '700',
    fontSize: 13,
  },
  detailCard: {
    backgroundColor: C.lightPink,
    borderRadius: 24,
    padding: 25,
    alignItems: 'center',
    marginBottom: 20,
  },
  detailIcon: {
    width: 65,
    height: 65,
    borderRadius: 21,
    backgroundColor: C.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  detailIconText: {
    color: C.pink,
    fontSize: 29,
    fontWeight: '700',
  },
  detailTitle: {
    color: C.dark,
    fontSize: 27,
    fontWeight: '800',
    marginBottom: 8,
  },
  detailDesc: {
    color: C.muted,
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 20,
  },
  infoCard: {
    backgroundColor: C.white,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 21,
    marginBottom: 20,
  },
  infoTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: C.dark,
    marginBottom: 19,
  },
  infoLabel: {
    color: C.muted,
    fontSize: 11,
    marginTop: 13,
    marginBottom: 5,
  },
  infoValue: {
    color: C.dark,
    fontSize: 14,
    lineHeight: 22,
  },
  statusText: {
    color: '#36876B',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 6,
  },
  settingButton: {
    backgroundColor: C.lightPink,
    borderRadius: 12,
    padding: 13,
    alignItems: 'center',
    marginTop: 20,
  },
  settingButtonText: {
    color: C.pink,
    fontWeight: '700',
    fontSize: 13,
  },
});
